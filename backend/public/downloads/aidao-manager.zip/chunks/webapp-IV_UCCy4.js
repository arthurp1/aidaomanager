import{R as t,j as e,a as o,A as r}from"./style-Daevf_VQ.js";t.createRoot(document.getElementById("root")).render(e.jsx(o.StrictMode,{children:e.jsx(r,{})}));
